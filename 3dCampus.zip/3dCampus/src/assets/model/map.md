```properties
白瓷砖=yellow tiles 0
白门=white door 1
草地=grass 2 
地砖=ground tiles 3
红木=dark wood 4 
灰砖地=grey brick ground 5
马路=road 6
木地板=red wood 7
木墙=yellow wood 8
墙体=white wall 9 
石阶=stone step 10
石砖/red=red ground 11
石砖/yellow=yellow ground 12
苔藓石砖=moss 13
```
